'''CSC108 Assignment 3: Social Networks'''

from typing import List, Tuple, Dict, TextIO


def load_profiles(profiles_file: TextIO, person_to_friends: Dict[str, List[str]], \
                  person_to_networks: Dict[str, List[str]]) -> None:
    '''Update the person_to_friends dictionary and the person_to_networks
    dictionary to include data from profiles_file.

    Docstring examples not given since the result depends on input data.
    '''


def get_average_friend_count(person_to_friends: Dict[str, List[str]]) -> float:
    '''
    '''
    
    
def get_families(person_to_friends: Dict[str, List[str]]) -> Dict[str, List[str]]:
    '''
    '''


def invert_network(person_to_networks: Dict[str, List[str]]) -> Dict[str, List[str]]:
    '''
    '''


def get_friends_of_friends(person_to_friends: Dict[str, List[str]], \
                           person: str) -> List[str]:
    '''
    '''
        
        
def make_recommendations(person: str, person_to_friends: Dict[str, List[str]], \
                         person_to_networks: Dict[str, List[str]]) \
                         -> List[Tuple[str, int]]:
    '''
    '''


def is_network_connected(person_to_friends: Dict[str, List[str]]) -> bool:
    '''
    '''


if __name__ == '__main__':
    # Do not move this code out of the __main__ block, and do not add any other 
    # testing code outside of the __main__ block.
    import doctest
    doctest.testmod()
